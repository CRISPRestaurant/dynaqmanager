import pandas as pd

employee_one = [-1, 1]
employee_two = [-1, 1]
employee_three = [-1, 1]
employee_four = [-1, 1]
employee_five = [-1, 1]

pay_action = [-1, -0.5, 0, 0.5, 1]
promotion_action = [-1, -0.5, 0, 0.5, 1]
benefits_action = [-1, -0.5, 0, 0.5, 1]
contigent_rewards_action = [-1, -0.5, 0, 0.5, 1]
operating_procedures_action = [-1, -0.5, 0, 0.5, 1]
nature_of_work_action = [-1, -0.5, 0, 0.5, 1]

state_and_action_combination_df = pd.DataFrame(columns=[
    "Employee One State",
    "Employee Two State",
    "Employee Three State",
    "Employee Four State",
    "Employee Five State",
    "Pay Action",
    "Promotion Action",
    "Benefits Action",
    "Contigent Rewards Action",
    "Operating Procedures Action",
    "Nature of Work Action"
])

iteration = 0
for a in employee_one:
    for b in employee_two:
        for c in employee_three:
            for d in employee_four:
                for e in employee_five:
                    for f in pay_action:
                        for g in promotion_action:
                            for h in benefits_action:
                                for i in contigent_rewards_action:
                                    for j in operating_procedures_action:
                                        for k in nature_of_work_action:
                                            row_to_add = pd.DataFrame(
                                                [[a, b, c, d, e, f, g, h, i, j, k]],
                                                columns=[
                                                    "Employee One State",
                                                    "Employee Two State",
                                                    "Employee Three State",
                                                    "Employee Four State",
                                                    "Employee Five State",
                                                    "Pay Action",
                                                    "Promotion Action",
                                                    "Benefits Action",
                                                    "Contigent Rewards Action",
                                                    "Operating Procedures Action",
                                                    "Nature of Work Action"
                                                ]
                                            )
                                            state_and_action_combination_df = pd.concat([state_and_action_combination_df, row_to_add])
                                            iteration += 1
                                            print(iteration)

state_and_action_combination_df.to_csv("states_and_actions_combinations.csv")