import numpy as np  
from scipy.stats import norm

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# mood instability parameter
# if f=0 mood does not bias reward perception 
# with f>0, mood exerts positive feedback, with reward perceived as larger in a good mood and as smaller in a bad mood 
# with f<0, mood corresponds to negative feedback, with reward perceived as smaller in a good mood and as larger in a bad mood
f = 1.5

n_timesteps = 10

eta_u = 0.1                   # learning rate 
eta_m = 0.5                   # mood update rate
v_init = np.array([-1, 1])   # initial values of each cue; we assume that both cues are present in the environment at all times
phi = np.array([1, 0]);       # attention to each cue; this determines the extent to which the cue is part of the state 
h_init = 0;                   # initial mood

reward_sequence = [-1, 1, 1, -1, -1, -1, 1, 1, -1, 1]

# Mood
M = []
M.append(np.tanh(h_init))

# Expectation
v = v_init
V = []
V_cues = []
V_cues.append(v_init)
V.append(np.dot(v,phi))

# Perceived reward
PR = []
PR.append(0) # no reward at t=0

# Reward prediction error
RPE = []
RPE.append(0) # no reward prediction error at t=0

for t in np.arange(n_timesteps):
    
  if t == 0:
    
    h = h_init     
    m = np.tanh(h) # compute initial mood
    v = v_init     # compute initial value

  # compute compound expected value weighted by attention
  v_compound = np.dot(v, phi)
  V.append(v_compound)  

  # perceive reward
  actual_reward = reward_sequence[t]
  perceived_reward = f*m + actual_reward
  PR.append(perceived_reward)

  # compute reward prediction error
  d = perceived_reward - v_compound
  RPE.append(d)

  # update expectation associated with each cue
  v = v + np.dot(eta_u*d, phi)
  V_cues.append(v)

  # update mood
  h = h + eta_m*(d-h)
  m = np.tanh(h)
  M.append(m)

timesteps = np.arange(n_timesteps+1)

fig, ax = plt.subplots(1,1,figsize=(10,4))
ax.axhline(y=0, color='grey', linestyle='dashed', linewidth=2)
plt.title('Attention to relatively worse (v = -1) vs. relatively better (v = 1) cue: ' + str(phi))
plt.plot(timesteps, V, color='grey', linewidth=3, label="Expectation (what we think will happen)");
plt.plot(timesteps[-n_timesteps:], reward_sequence, color='grey', marker='s', linestyle='None', label="Outcome (what actually happens)");
plt.bar(timesteps, RPE, color='grey', width=0.1, alpha=0.5, label="Prediction error");
plt.plot(timesteps, M, color='orange', linewidth=3, label="Mood");
plt.legend(loc="best", bbox_to_anchor=(1.3, 1))
plt.ylim([-2, 2])
ax.set_xticks(timesteps)
ax.set_yticks([-1, 0, 1])
sns.despine()

plt.show()