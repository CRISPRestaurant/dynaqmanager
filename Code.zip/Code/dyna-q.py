import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import os

import pandas as pd
import numpy as np
from math import *
import random
import matplotlib.pyplot as plt
import seaborn as sns

from scipy import stats as st

def e_greedy(state, q_value_df, e):
    q_value_with_state_only = q_value_df.loc[
        (q_value_df["Employee One State"] == state[0]) &
        (q_value_df["Employee Two State"] == state[1]) &
        (q_value_df["Employee Three State"] == state[2]) &
        (q_value_df["Employee Four State"] == state[3]) &
        (q_value_df["Employee Five State"] == state[4])
    ]

    if (np.random.rand() >= e):
        action_row = q_value_with_state_only.sort_values(by = "Q-Value", ascending = True).iloc[0]
    else:
        action_row = q_value_with_state_only.sample().iloc[0]
    
    return [
            action_row["Pay Action"],
            action_row["Promotion Action"],
            action_row["Benefits Action"],
            action_row["Contingent Rewards Action"],
            action_row["Operating Procedures Action"],
            action_row["Nature of Work Action"]
    ]

def update_moods_and_obtain_new_state(action, mood_profile, employee_history_df, threshold_for_quitting, exponential_reward_initial_value, exponential_reward_constant):
    possible_action_means = [10.5, 11.5, 13.1, 13.4, 12.5, 19.2]
    possible_action_sds = [5.1, 5.1, 5, 5.1, 4.6, 4.4]

    non_normalized_action = np.array(action) * np.array(possible_action_sds) + np.array(possible_action_means)

    f = 1.5
    eta_u = 0.1
    eta_m = 0.5
    
    turnovers = 0
    new_state = []
    for employee_num in range(5):
        specific_employee_mood_df = mood_profile.loc[employee_mood_df["Employee"] == employee_num + 1].sort_values(by = "Time", ascending = True)

        last_time_step_row = specific_employee_mood_df.iloc[-1]

        # Perceive reward
        perceived_reward_pay = f * last_time_step_row["Mood"] + non_normalized_action[0]
        perceived_reward_promotion = f * last_time_step_row["Mood"] + non_normalized_action[1]
        perceived_reward_benefits = f * last_time_step_row["Mood"] + non_normalized_action[2]
        perceived_reward_contingent_rewards = f * last_time_step_row["Mood"] + non_normalized_action[3]
        perceived_reward_operating_procedures = f * last_time_step_row["Mood"] + non_normalized_action[4]
        perceived_reward_nature_of_work = f * last_time_step_row["Mood"] + non_normalized_action[5]

        # Reward Prediction Error
        reward_prediction_error_pay = perceived_reward_pay - last_time_step_row["Expected Value Pay"]
        reward_prediction_error_promotion = perceived_reward_promotion - last_time_step_row["Expected Value Promotion"]
        reward_prediction_error_benefits = perceived_reward_benefits - last_time_step_row["Expected Value Benefits"]
        reward_prediction_error_contingent_rewards = perceived_reward_contingent_rewards - last_time_step_row["Expected Value Contingent Rewards"]
        reward_prediction_error_operating_procedures = perceived_reward_operating_procedures - last_time_step_row["Expected Value Operating Procedures"]
        reward_prediction_error_nature_of_work = perceived_reward_nature_of_work - last_time_step_row["Expected Value Nature of Work"]

        # New Expectation
        new_expected_pay = last_time_step_row["Expected Value Pay"] + eta_u * reward_prediction_error_pay
        new_expected_promotion = last_time_step_row["Expected Value Promotion"] + eta_u * reward_prediction_error_promotion
        new_expected_benefits = last_time_step_row["Expected Value Benefits"] + eta_u * reward_prediction_error_benefits
        new_expected_contingent_rewards = last_time_step_row["Expected Value Contingent Rewards"] + eta_u * reward_prediction_error_contingent_rewards
        new_expected_operating_procedures = last_time_step_row["Expected Value Operating Procedures"] + eta_u * reward_prediction_error_operating_procedures
        new_expected_nature_of_work = last_time_step_row["Expected Value Nature of Work"] + eta_u * reward_prediction_error_nature_of_work

        non_normalized_mood = last_time_step_row["Non-Normalized Mood"] + eta_m * (np.mean([reward_prediction_error_pay, reward_prediction_error_promotion, reward_prediction_error_benefits, reward_prediction_error_contingent_rewards, reward_prediction_error_operating_procedures, reward_prediction_error_nature_of_work]) - last_time_step_row["Non-Normalized Mood"])
        normalized_mood = np.tanh(non_normalized_mood)

        reward_prediction_list = []
        reward_predictions_errors = [reward_prediction_error_pay, reward_prediction_error_promotion, reward_prediction_error_benefits, reward_prediction_error_contingent_rewards, reward_prediction_error_operating_procedures, reward_prediction_error_nature_of_work]
        for error in reward_predictions_errors:
            if error > 0:
                reward_prediction_list.append(1)
            else:
                reward_prediction_list.append(-1)
        

        if normalized_mood <= threshold_for_quitting:
            employee_row = employee_history_df.loc[employee_history_df["End Time"].isna()]
            employee_row["End Time"] = last_time_step_row["Time"]

            employee_history_df = employee_history_df.append({
                "Employee": employee_num + 1,
                "Start Time": last_time_step_row["Time"] + 1
            }, ignore_index = True)

            mood_profile_new_row = pd.DataFrame(
                [[
                    employee_num + 1,
                    0, 
                    0, 
                    0, 
                    np.random.normal(10.5, 5.1), 
                    np.random.normal(11.5, 5.1), 
                    np.random.normal(13.1, 5),
                    np.random.normal(13.4, 5.1),
                    np.random.normal(12.5, 4.6),
                    np.random.normal(19.2, 4.4),
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]],
                columns=[
                    "Employee",
                    "Time",
                    "Non-Normalized Mood",
                    "Mood",
                    "Expected Value Pay",
                    "Expected Value Promotion",
                    "Expected Value Benefits",
                    "Expected Value Contingent Rewards",
                    "Expected Value Operating Procedures",
                    "Expected Value Nature of Work",
                    "Perceived Reward Pay",
                    "Perceived Reward Promotion",
                    "Perceived Reward Benefits",
                    "Perceived Reward Contingent Rewards",
                    "Perceived Reward Operating Procedures",
                    "Perceived Reward Nature of Work"
                ]
            )

            mood_profile = pd.concat([mood_profile, mood_profile_new_row])

            turnovers += 1
            new_state.append(-1)
        else:
            mood_profile_new_row = pd.DataFrame(
                [[
                    employee_num + 1,
                    last_time_step_row["Time"] + 1, 
                    non_normalized_mood, 
                    normalized_mood, 
                    new_expected_pay, 
                    new_expected_promotion, 
                    new_expected_benefits,
                    new_expected_contingent_rewards,
                    new_expected_operating_procedures,
                    new_expected_nature_of_work,
                    perceived_reward_pay,
                    perceived_reward_promotion,
                    perceived_reward_benefits,
                    perceived_reward_contingent_rewards,
                    perceived_reward_operating_procedures,
                    perceived_reward_nature_of_work
                ]],
                columns=[
                    "Employee",
                    "Time",
                    "Non-Normalized Mood",
                    "Mood",
                    "Expected Value Pay",
                    "Expected Value Promotion",
                    "Expected Value Benefits",
                    "Expected Value Contingent Rewards",
                    "Expected Value Operating Procedures",
                    "Expected Value Nature of Work",
                    "Perceived Reward Pay",
                    "Perceived Reward Promotion",
                    "Perceived Reward Benefits",
                    "Perceived Reward Contingent Rewards",
                    "Perceived Reward Operating Procedures",
                    "Perceived Reward Nature of Work"
                ]
            )

            mood_profile = pd.concat([mood_profile, mood_profile_new_row])

            new_state.append(st.mode(reward_prediction_list).mode[0])
    
    return np.sum(new_state) + exponential_reward_initial_value * exp(-1 * exponential_reward_constant * turnovers), new_state

combination_number = input("Which combinations do you want to run? ")
combination_df = pd.read_csv("../Combinations/%s.csv" % (combination_number))

for combination_iter, combination_row in combination_df.iterrows():
    print(combination_row)
    folder_name = "../Data/%s,%s,%s,%s" % (combination_row["Threshold"], combination_row["Initial Value"], combination_row["Constant"], combination_row["Alpha"])
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    q_value_df = pd.read_csv("states_and_actions_combinations.csv")
    model_df = pd.read_csv("states_and_actions_combinations.csv")

    q_value_initial_values = np.random.normal(0, 1, 500000)
    q_value_df.insert(11, "Q-Value", q_value_initial_values, True)
    q_value_df.to_csv("%s/Q-Values Initial.csv" % (folder_name))

    model_df.insert(11, "New Employee One State", None)
    model_df.insert(12, "New Employee Two State", None)
    model_df.insert(13, "New Employee Three State", None)
    model_df.insert(14, "New Employee Four State", None)
    model_df.insert(15, "New Employee Five State", None)
    model_df.insert(16, "Reward", None)

    # Initialize preferences of employees
    employee_preference_df = pd.DataFrame(columns=[
        "Employee",
        "Pay",
        "Promotion",
        "Supervision",
        "Benefits",
        "Contingent Rewards",
        "Operating Procedures",
        "Co-workers",
        "Nature of Work",
        "Organizational Commitment"
    ])

    for i in range(5):
        employee_preference_df = employee_preference_df.append({
            "Employee": i + 1,
            "Pay": np.random.normal(10.5, 5.1),
            "Promotion": np.random.normal(11.5, 5.1),
            "Supervision": np.random.normal(19.9, 4.6),
            "Benefits": np.random.normal(13.1, 5),
            "Contingent Rewards": np.random.normal(13.4, 5.1),
            "Operating Procedures": np.random.normal(12.5, 4.6),
            "Co-workers": np.random.normal(18.8, 3.7),
            "Nature of Work": np.random.normal(19.2, 4.4),
            "Organizational Commitment": np.random.normal(4.4, 0.98)
        }, ignore_index = True)
    
    employee_preference_df.to_csv("%s/Initial Employee Preferences.csv" % (folder_name))

    # Calculated new updated state and moods for each employee after previous state and action
    employee_mood_df = pd.DataFrame(columns = [
        "Employee",
        "Time",
        "Non-Normalized Mood",
        "Mood",
        "Expected Value Pay",
        "Expected Value Promotion",
        "Expected Value Benefits",
        "Expected Value Contingent Rewards",
        "Expected Value Operating Procedures",
        "Expected Value Nature of Work",
        "Perceived Reward Pay",
        "Perceived Reward Promotion",
        "Perceived Reward Benefits",
        "Perceived Reward Contingent Rewards",
        "Perceived Reward Operating Procedures",
        "Perceived Reward Nature of Work"
    ])

    employee_history_df = pd.DataFrame(columns=[
        "Employee",
        "Start Time",
        "End Time"
    ])
    for i in range(5):
        employee_mood_df = employee_mood_df.append({
            "Employee": i + 1,
            "Time": 0,
            "Non-Normalized Mood": 0,
            "Mood": 0,
            "Expected Value Pay": employee_preference_df.loc[employee_preference_df["Employee"] == i + 1].iloc[0]["Pay"],
            "Expected Value Promotion": employee_preference_df.loc[employee_preference_df["Employee"] == i + 1].iloc[0]["Promotion"],
            "Expected Value Benefits": employee_preference_df.loc[employee_preference_df["Employee"] == i + 1].iloc[0]["Benefits"],
            "Expected Value Contingent Rewards": employee_preference_df.loc[employee_preference_df["Employee"] == i + 1].iloc[0]["Contingent Rewards"],
            "Expected Value Operating Procedures": employee_preference_df.loc[employee_preference_df["Employee"] == i + 1].iloc[0]["Contingent Rewards"],
            "Expected Value Nature of Work": employee_preference_df.loc[employee_preference_df["Employee"] == i + 1].iloc[0]["Nature of Work"],
            "Perceived Reward Pay": 0,
            "Perceived Reward Promotion": 0,
            "Perceived Reward Benefits": 0,
            "Perceived Reward Contingent Rewards": 0,
            "Perceived Reward Operating Procedures": 0,
            "Perceived Reward Nature of Work": 0
        }, ignore_index = True)

        employee_history_df = employee_history_df.append({
            "Employee": i + 1,
            "Start Time": 0
        }, ignore_index = True)

    epsilon = 0.30
    threshold_for_quitting = combination_row["Threshold"]
    exponential_initial_value = combination_row["Initial Value"]
    exponential_constant = combination_row["Constant"]
    alpha = combination_row["Alpha"]
    gamma = 0.1

    state = [
        random.choice([-1, 1]),
        random.choice([-1, 1]),
        random.choice([-1, 1]),
        random.choice([-1, 1]),
        random.choice([-1, 1])
    ]
    state_history_df = pd.DataFrame([[0, 0] + state], columns = ["Time", "Reward", "Employee One State", "Employee Two State", "Employee Three State", "Employee Four State", "Employee Five State"])
    action_history_df = pd.DataFrame(columns = ["Time", "Pay Action", "Promotion Action", "Benefits Action", "Contingent Rewards Action", "Operating Procedures Action", "Nature of Work Action"])
    total_reward = 0
    for i in range(1000):
        action_to_take = e_greedy(state, q_value_df, epsilon)

        new_action_history_row = pd.DataFrame([[i + 1] + action_to_take], columns = ["Time", "Pay Action", "Promotion Action", "Benefits Action", "Contingent Rewards Action", "Operating Procedures Action", "Nature of Work Action"])
        action_history_df = pd.concat([action_history_df, new_action_history_row])

        reward, new_state = update_moods_and_obtain_new_state(action_to_take, employee_mood_df, employee_history_df, threshold_for_quitting, exponential_initial_value, exponential_constant)

        new_state_history_row = pd.DataFrame([[i + 1, reward] + new_state], columns = ["Time", "Reward",  "Employee One State", "Employee Two State", "Employee Three State", "Employee Four State", "Employee Five State"])
        state_history_df = pd.concat([state_history_df, new_state_history_row])
        
        q_value_row = q_value_df.loc[
            (q_value_df["Employee One State"] == state[0]) &
            (q_value_df["Employee Two State"] == state[1]) &
            (q_value_df["Employee Three State"] == state[2]) &
            (q_value_df["Employee Four State"] == state[3]) &
            (q_value_df["Employee Five State"] == state[4]) &
            (q_value_df["Pay Action"] == action_to_take[0]) &
            (q_value_df["Promotion Action"] == action_to_take[1]) &
            (q_value_df["Benefits Action"] == action_to_take[2]) &
            (q_value_df["Contingent Rewards Action"] == action_to_take[3]) &
            (q_value_df["Operating Procedures Action"] == action_to_take[4]) &
            (q_value_df["Nature of Work Action"] == action_to_take[5])
        ]
        q_value_new_state_space = q_value_df.loc[
            (q_value_df["Employee One State"] == new_state[0]) &
            (q_value_df["Employee Two State"] == new_state[1]) &
            (q_value_df["Employee Three State"] == new_state[2]) &
            (q_value_df["Employee Four State"] == new_state[3]) &
            (q_value_df["Employee Five State"] == new_state[4])
        ]

        q_value_row.loc[q_value_row.index[0], "Q-Value"] = q_value_row["Q-Value"].to_list()[0] + alpha * (reward + gamma * q_value_new_state_space.sort_values(by = "Q-Value", ascending = False)["Q-Value"].to_list()[0] - q_value_row["Q-Value"].to_list()[0])
        model_df_row = model_df.loc[
            (model_df["Employee One State"] == state[0]) &
            (model_df["Employee Two State"] == state[1]) &
            (model_df["Employee Three State"] == state[2]) &
            (model_df["Employee Four State"] == state[3]) &
            (model_df["Employee Five State"] == state[4]) &
            (model_df["Pay Action"] == action_to_take[0]) &
            (model_df["Promotion Action"] == action_to_take[1]) &
            (model_df["Benefits Action"] == action_to_take[2]) &
            (model_df["Contingent Rewards Action"] == action_to_take[3]) &
            (model_df["Operating Procedures Action"] == action_to_take[4]) &
            (model_df["Nature of Work Action"] == action_to_take[5])
        ]

        model_df_row.loc[model_df_row.index[0], "New Employee One State"] = new_state[0]
        model_df_row.loc[model_df_row.index[0], "New Employee Two State"] = new_state[1]
        model_df_row.loc[model_df_row.index[0], "New Employee Three State"] = new_state[2]
        model_df_row.loc[model_df_row.index[0], "New Employee Four State"] = new_state[3]
        model_df_row.loc[model_df_row.index[0], "New Employee Five State"] = new_state[4]
        model_df_row.loc[model_df_row.index[0], "Reward"] = reward

        for j in range(10):
            model_df_occupied = model_df.loc[
                (~model_df["New Employee One State"].isna()) &
                (~model_df["New Employee Two State"].isna()) &
                (~model_df["New Employee Three State"].isna()) &
                (~model_df["New Employee Four State"].isna()) &
                (~model_df["New Employee Five State"].isna())
            ]

            if model_df_occupied.shape[0] != 0:
                random_row = model_df_occupied.sample()

                q_value_row = q_value_df.loc[
                    (q_value_df["Employee One State"] == random_row["Employee One State"]) &
                    (q_value_df["Employee Two State"] == random_row["Employee Two State"]) &
                    (q_value_df["Employee Three State"] == random_row["Employee Three State"]) &
                    (q_value_df["Employee Four State"] == random_row["Employee Four State"]) &
                    (q_value_df["Employee Five State"] == random_row["Employee Five State"]) &
                    (q_value_df["Pay Action"] == random_row["Pay Action"]) &
                    (q_value_df["Promotion Action"] == random_row["Promotion Action"]) &
                    (q_value_df["Benefits Action"] == random_row["Benefits Action"]) &
                    (q_value_df["Contingent Rewards Action"] == random_row["Contingent Rewards Action"]) &
                    (q_value_df["Operating Procedures Action"] == random_row["Operating Procedures Action"]) &
                    (q_value_df["Nature of Work Action"] == random_row["Nature of Work Action"])
                ]

                q_value_with_future_state = q_value_df.loc[
                    (q_value_df["Employee One State"] == random_row["Employee One State"]) &
                    (q_value_df["Employee Two State"] == random_row["Employee Two State"]) &
                    (q_value_df["Employee Three State"] == random_row["Employee Three State"]) &
                    (q_value_df["Employee Four State"] == random_row["Employee Four State"]) &
                    (q_value_df["Employee Five State"] == random_row["Employee Five State"])
                ]

                q_value_row.loc[q_value_row.index[0], "Q-Value"] = q_value_row["Q-Value"].to_list()[0] + alpha * (random_row["Reward"].to_list()[0] + gamma * q_value_with_future_state.sort_values(by = "Q-Value", ascending = False).iloc[0]["Q-Value"].to_list()[0] - q_value_row["Q-Value"].to_list()[0])
        
        state = new_state
        total_reward += reward

        if i == 500000:
            q_value_df.to_csv("%s/Q-Value Middle.csv" % (folder_name))
            
        print("Iteration %s" % (i))
    
    q_value_df.to_csv("%s/Q-Value Final.csv" % (folder_name))
    model_df.to_csv("%s/Model.csv" % (folder_name))
    state_history_df.to_csv("%s/State History.csv" % (folder_name))
    action_history_df.to_csv("%s/Action History.csv" % (folder_name))
    employee_mood_df.to_csv("%s/Employee Mood.csv" % (folder_name))
    employee_history_df.to_csv("%s/Employee History.csv" % (folder_name))

    with open("%s/Reward.txt" % (folder_name), "w") as reward_file:
        reward_file.write("%s" % (total_reward))