import pandas as pd

threshold_for_quitting_combos = [-0.8, -0.85, -0.90, -1.0]
exponential_initial_value = [1, 5, 10, 20]
exponential_constant = [0.01, 0.1, 0.5, 1]
alpha = [-1.0, -0.1, 0.1, 1]

combination_number = 1
combination_df = pd.DataFrame(columns=[
    "Threshold",
    "Initial Value",
    "Constant",
    "Alpha"
])

for a in threshold_for_quitting_combos:
    for b in exponential_initial_value:
        for c in exponential_constant:
            for d in alpha:
                if combination_df.shape[0] == 16:
                    combination_df.to_csv("../Combinations/%s.csv" % (combination_number))
                    combination_number += 1
                    combination_df = pd.DataFrame(columns=[
                        "Threshold",
                        "Initial Value",
                        "Constant",
                        "Alpha"
                    ])
                
                combination_df = combination_df.append({
                    "Threshold": a,
                    "Initial Value": b,
                    "Constant": c,
                    "Alpha": d
                }, ignore_index = True)

combination_df.to_csv("../Combinations/20.csv")