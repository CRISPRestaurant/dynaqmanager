import pandas as pd
import seaborn as sns
import matplolib.pyplot as plt
import numpy as np

alphas = [-1.0, -0.1, 0.1, 1.0]
fig, axs = plt.subplots(3, 4)
axs[0, 0].title.set_text("Q-Value for alpha=-1, t=0")
axs[1, 0].title.set_text("Q-Value for alpha=-1, t=500k")
axs[2, 0].title.set_text("Q-Value for alpha=-1, t=1mil")
axs[0, 1].title.set_text("Q-Value for alpha=-0.1, t=0")
axs[1, 1].title.set_text("Q-Value for alpha=-0.1, t=500k")
axs[2, 1].title.set_text("Q-Value for alpha=-0.1, t=1mil")
axs[0, 2].title.set_text("Q-Value for alpha=0.1, t=0")
axs[1, 2].title.set_text("Q-Value for alpha=0.1, t=500k")
axs[2, 2].title.set_text("Q-Value for alpha=0.1, t=1mil")
axs[0, 3].title.set_text("Q-Value for alpha=1, t=0")
axs[1, 3].title.set_text("Q-Value for alpha=1, t=500k")
axs[2, 3].title.set_text("Q-Value for alpha=1, t=1mil")

optimal_threshold = -0.8
optimal_initial_value = 1.0
optimal_constant = 0.1

for alpha_id in len(range(alphas)):
    folder_name = "../Data/%s,%s,%s,%s" % (optimal_threshold, optimal_initial_value, optimal_constant, alphas[alpha_id])

    q_value_initial = pd.read_csv("%s/Q-Values Initial.csv")
    q_value_middle = pd.read_csv("%s/Q-Value Middle.csv")
    q_value_final = pd.read_csv("%s/Q-Value Final.csv")

    sns.heatmap(np.reshape(q_value_initial["Q-Value"].to_numpy(), (500, 1000)), ax = axs[0, alpha_id])
    sns.heatmap(np.reshape(q_value_middle["Q-Value"].to_numpy(), (500, 1000)), ax = axs[1, alpha_id])
    sns.heatmap(np.reshape(q_value_final["Q-Value"].to_numpy(), (500, 1000)), ax = axs[2, alpha_id])