import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from statannotations.Annotator import Annotator
from itertools import combinations

optimal_threshold = -0.8
optimal_initial_value = 1.0
optimal_constant = 0.1

alphas = [-1.0, -0.1, 0.1, 1.0]

turnover_distribution_df = pd.DataFrame(columns=[
    "Turnover Rate",
    "Alpha"
])

for alpha in alphas:
    folder_name = "../Data/%s,%s,%s,%s" % (optimal_threshold, optimal_initial_value, optimal_constant, alpha)

    employee_history_df = pd.read_csv("%s/Employee History.csv" % (folder_name))
    turnover_history = []

    for i in range(50000):
        start_range = i * 20
        end_range = start_range + 19

        employees_quitting_within_time = employee_history_df.loc[(employee_history_df["End Time"] >= start_range) & (employee_history_df["End Time"] <= end_range)]

        turnover_history.append(100 * (employees_quitting_within_time / 5))
    
    turnover_distribution_alpha_df = pd.DataFrame({
            "Turnover Rate": turnover_history,
            "Alpha": np.ones(50000, dtype = np.float64) * float(alpha)
    })

    turnover_distribution_df = pd.concat([turnover_distribution_df, turnover_distribution_alpha_df])

ax = sns.boxplot(data = turnover_distribution_df, x = "Alpha", y = "Turnover Rate", order = alphas)
pairs = list(combinations(alphas, r = 2))

annotator = Annotator(ax, pairs, data = turnover_distribution_df, x = "Alpha", y = "Turnover Rate", order = alphas)
annotator.configure(test = "Brunner-Munzel", comparisons_correction = "Benjamini-Yekutieli")
annotator.apply_and_annotate()

plt.title("Turnover Rate Across Different Alpha Conditions (Brunner-Munzel Test with Benjamini-Yekutieli FDR correction)")
plt.show()
