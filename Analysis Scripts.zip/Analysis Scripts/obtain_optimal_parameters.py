import pandas as pd
import seaborn as sns
import matplolib.pyplot as plt
import numpy as np

threshold_for_quitting_combos = [-0.8, -0.85, -0.90, -1.0]
exponential_initial_value = [1, 5, 10, 20]
exponential_constant = [0.01, 0.1, 0.5, 1]
alphas = [-1.0, -0.1, 0.1, 1.0]

mean_squared_error = pd.DataFrame(columns=[
    "Parameters",
    "MSE"
])

for a in threshold_for_quitting_combos:
    for b in exponential_initial_value:
        for c in exponential_constant:
            mean_squared_error = 0
            for d in alphas:
                folder_name = "../Data/%s,%s,%s,%s" % (a, b, c, d)

                employee_mood_df = pd.read_csv("%s/Employee Mood.csv" % (folder_name))
                employee_history_df = pd.read_csv("%s/Employee History.csv" % (folder_name))

                for i in range(5):
                    employee_specific_df = employee_mood_df.loc[employee_mood_df["Employee"] == i + 1].sort_values(by = "Time", ascending = True)

                    expected_value_pay = employee_specific_df["Expected Value Pay"].to_numpy()
                    expected_value_promotion = employee_specific_df["Expected Value Promotion"].to_numpy()
                    expected_value_benefits = employee_specific_df["Expected Value Benefits"].to_numpy()
                    expected_value_contingent_rewards = employee_specific_df["Expected Value Contingent Rewards"].to_numpy()
                    expected_value_operating_procedures = employee_specific_df["Expected Value Operating Procedures"].to_numpy()
                    expected_value_nature_of_work = employee_specific_df["Expected Value Nature of Work"].to_numpy()

                    total_expected_value = expected_value_pay + expected_value_promotion + expected_value_benefits + expected_value_contingent_rewards + expected_value_operating_procedures + expected_value_nature_of_work
                    turnover_intention_data = 1 / (1 + np.exp(-1 * (a - employee_specific_df["Mood"].to_numpy())))

                    correlation_coefficient = np.corrcoef(total_expected_value, turnover_intention_data)[1][0]
                    squared_error = (correlation_coefficient - -0.066) ** 2
                    mean_squared_error += squared_error
            
            mean_squared_error = mean_squared_error.append({
                "Parameters": "%s,%s,%s" % (a, b, c),
                "MSE": mean_squared_error / 4
            }, ignore_index = True)

mean_squared_error = mean_squared_error.sort_values(by = ["MSE"], ascending=True)
sns.barplot(data = mean_squared_error, x = "Parameters", y = "MSE")
plt.title("MSE between DYNA-Q Correlation Coefficients and Literature Correlation Coefficients Across Parameters")
plt.xticks(rotation = 90)
plt.tight_layout()
plt.show()